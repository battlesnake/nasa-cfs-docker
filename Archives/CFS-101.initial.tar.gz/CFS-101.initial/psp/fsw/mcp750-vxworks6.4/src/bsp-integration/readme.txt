The module cfeSupport.c contains functions that are used to run the cFE on 
the MCP750. This module should be integrated into the vxWorks kernel image before
trying to load the cFE core module.


